import pymongo
import tweepy
from user import User
import ast
import json


def updateDb():
	user_names = ['ibnlive','timesnow','HeadlinesToday','ndtv']
	connection = pymongo.MongoClient("localhost", 27017)
	
	# create a database if not exists
	db = connection.twitter

	# crate collections for users
	users = db.users
	
	auth = tweepy.OAuthHandler("oURSVON6rRvw7gi3aCMNYg","lFzae5HXsGwhyqxdbKtYStzPy0IRI7oEAIoXbvDiRDI")
	auth.set_access_token("2243361606-6WHyclCNIuj2uAq6cJKZtScNI2XGDxCWANSlX64","lIDvQ8pTaJLDDyBIXWzwOAxwA0QXn9moFL6QUp7v1RytL")
	api = tweepy.API(auth)
	try:
		data_list = []
		for user_name in user_names:
			user = User(user_name,api,382135610024005632L)
			user.update(api)
			data_list.append({'user_name': user_name,'data' : user.getUserDict()})

		users.insert(data_list)
	except:
		print "some kirick"

def getDataForPlotting():
	connection = pymongo.MongoClient("localhost", 27017)
	db = connection.twitter
	cursor = db.users.find()
	
	data = []

	for eachObject in cursor:
		
		temp_dict = {}
		temp_dict['name'] = eachObject['data']['screen_name']
		temp_dict['data'] = { "retweet_count": eachObject['data']['retweet_count'] , "followers_count" :eachObject['data']['followers_count'],"tweet_count":eachObject['data']['tweet_count'] }
		data.append(temp_dict)
	return data

if __name__ == '__main__':
	print getDataForPlotting()
