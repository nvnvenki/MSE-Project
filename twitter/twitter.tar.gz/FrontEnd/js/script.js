$(function(){


		var response = null
		var channel_names = []
		function getChannelNames()
		{

			if(response)
			{
				$.each(response,function(index,element){
					channel_names.push(element['name'])
				})
			}
			return channel_names
		}

		function getData(type)
		{
			data = []
			if(response)
			{
				$.each(response,function(index,element){

					var temp = []
					temp.push(element['name'])
					temp.push(element['data'][type])
					data.push(temp)
				})
				
			}
			return data
		}

		function getDataRatio()
		{
			data = []
			if(response)
			{
				$.each(response,function(index,element){

					var temp = []
					temp.push(element['name'])
					var ratio = element['data']['tweet_count'] / element['data']['followers_count']
					temp.push(1 / ratio)
					data.push(temp)
				})
				
			}
			return data
		}

		$.get("http://localhost:1234",function(data){   
		  	response = data

		}).done(function(){  

			// Pie charts
			Highcharts.getOptions().colors = Highcharts.map(Highcharts.getOptions().colors, function(color) {
			    	return {
			       		radialGradient: { cx: 0.5, cy: 0.3, r: 0.7 },
				        stops: [
				            [0, color],
				            [1, Highcharts.Color(color).brighten(-0.3).get('rgb')] // darken
				        ]
			    	}
			})

			$("#graph-container-retweets").highcharts({
				chart: {
             		 	 	plotBackgroundColor: null,
                			plotBorderWidth: null,
               	 			plotShadow: false
            			},

				title : {
					text : "Retweet counts of the channels tweets"
				},
				subtitle: {
	       				text: "Source: Twitter"
	       			},
	       			plotOptions: {

			                pie: {
			                    allowPointSelect: true,
			                    cursor: 'pointer',
			                    dataLabels: {
			                        enabled: true,
			                        color: '#000000',
			                        connectorColor: '#000000',
			                        formatter: function() {
			                            return '<b>'+ this.point.name +'</b>: '+ this.percentage +' %';
			                        }
			                    }
			                }
			        },
	       			series : [{
	       				type:'pie',
	       				name : 'Retweets ',
	       				data : getData("retweet_count")
	       			}]

			})

			$("#graph-container-tweets").highcharts({
				chart: {
             		 	 	plotBackgroundColor: null,
                			plotBorderWidth: null,
               	 			plotShadow: false
            			},

				title : {
					text : "Tweet counts of the channels tweets"
				},
				subtitle: {
	       				text: "Source: Twitter"
	       			},
	       			plotOptions: {

			                pie: {
			                    allowPointSelect: true,
			                    cursor: 'pointer',
			                    dataLabels: {
			                        enabled: true,
			                        color: '#000000',
			                        connectorColor: '#000000',
			                        formatter: function() {
			                            return '<b>'+ this.point.name +'</b>: '+ this.percentage +' %';
			                        }
			                    }
			                }
			        },
	       			
	       			series : [{
	       				type:'pie',
	       				name : 'tweets ',
	       				data : getData("tweet_count")
	       			}]

			})
		
			$("#graph-container-followers").highcharts({
				chart: {
             		 	 	plotBackgroundColor: null,
                			plotBorderWidth: null,
               	 			plotShadow: false
            			},

				title : {
					text : "Followers counts of the channels"
				},
				subtitle: {
	       				text: "Source: Twitter"
	       			},
	       			plotOptions: {

			                pie: {
			                    allowPointSelect: true,
			                    cursor: 'pointer',
			                    dataLabels: {
			                        enabled: true,
			                        color: '#000000',
			                        connectorColor: '#000000',
			                        formatter: function() {
			                            return '<b>'+ this.point.name +'</b>: '+ this.percentage +' %';
			                        }
			                    }
			                }
			        },
	       			series : [{
	       				type:'pie',
	       				name : 'Followers ',
	       				data : getData("followers_count")
	       			}]

			})

			$("#graph-container-tweets-followers").highcharts({
				chart: {
             		 	 	plotBackgroundColor: null,
                			plotBorderWidth: null,
               	 			plotShadow: false
            			},

				title : {
					text : "Popularity"
				},
				subtitle: {
	       				text: "Source: Twitter"
	       			},
	       			plotOptions: {

			                pie: {
			                    allowPointSelect: true,
			                    cursor: 'pointer',
			                    dataLabels: {
			                        enabled: true,
			                        color: '#000000',
			                        connectorColor: '#000000',
			                        formatter: function() {
			                            return '<b>'+ this.point.name +'</b>: '+ this.percentage +' %';
			                        }
			                    }
			                }
			        },
	       			
	       			series : [{
	       				type:'pie',
	       				name : 'tweets per number of follower',
	       				data : getDataRatio()
	       			}]

			})
			

			// Line charts	

		 }) 

})